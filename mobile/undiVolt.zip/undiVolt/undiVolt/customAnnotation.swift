//
//  customAnnotation.swift
//  undiVolt
//
//  Created by Cornel Amariei on 18/10/15.
//  Copyright © 2015 Cornel Amariei. All rights reserved.
//

import Foundation
import MapKit

class customAnnotation: NSObject, MKAnnotation {
    let locationName: String
    let title: String;
    let discipline: String
    let coordinate: CLLocationCoordinate2D
    
    init(titleS: String, subtitleS: String, discipline: String, coordinate: CLLocationCoordinate2D) {
        self.title = titleS;
        self.subtitle = subtitleS;
        self.locationName = locationName
        self.discipline = discipline
        self.coordinate = coordinate
        
        super.init()
    }
}
