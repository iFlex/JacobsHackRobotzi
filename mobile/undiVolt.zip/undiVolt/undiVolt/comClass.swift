//
//  comClass.swift
//  undiVolt
//
//  Created by Cornel Amariei on 17/10/15.
//  Copyright © 2015 Cornel Amariei. All rights reserved.
//

import Foundation
import UIKit



class comClass {
    // SINGLETON CLASS
    static let sharedInstance = comClass();
    
    // GLOBAL VARS
    
    public var caption = 0;
    public var id = 0; 
    
    
    // Init Socket.IO connection to our server
    //let socketIO = SocketIOClient(socketURL: "10.80.57.119:8101");
    let socketIO = SocketIOClient(socketURL: "52.26.81.246:8080");
    
    let endpoint = "live";
    var storage: Dictionary<String,Dictionary<String,AnyObject>> = Dictionary<String,Dictionary<String,AnyObject>>();
    
    func getLatestData(from:String) -> Dictionary<String,AnyObject>!{
        return self.storage[from];
    }
    
    func clearLastData(from:String){
        self.storage[from] = nil;
    }
    
    func makeCopyOfDict(location:String,dct:Dictionary<String,AnyObject>) {
        var ndict = Dictionary<String,AnyObject>();
        for k in dct.keys {
            ndict[k] = dct[k]!.copy();
        }
        self.storage[location] = ndict;
    }
    // Class initialisation
    private init() {
        
        //storage = Dictionary<String,AnyObject>();
        socketIO.on("connect") {data, ack in
            print("socket connected")
            //self.socketIO.emit("loop", "{\"test\":123}")
            
        }
        
        socketIO.on(endpoint){data, ack in
            do {
                var parsed:Dictionary<String,AnyObject> = self.fromJSON(data[0] as! String);
                self.makeCopyOfDict(parsed["endpoint"] as! String,dct: parsed);
            } catch {
                print("INVALID JSON DATA:")
                print(data);
            }
        }
        
        socketIO.connect();
        
    }
    
    func connect(){
        socketIO.connect();
        
    }
    
    
    // JSON Parser
    func fromJSON(text: String) -> Dictionary<String,AnyObject>! {
        do {
            if let data = text.dataUsingEncoding(NSUTF8StringEncoding) {
                let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions()) as? Dictionary<String,AnyObject>
                return json
            }
        }catch {
            return nil;
        }
        return nil;
    }
    
    // JSON Encoder
    func toJSON(dict:Dictionary<String,AnyObject>) ->String {
        do {
            let jsonData = try NSJSONSerialization.dataWithJSONObject(dict, options: NSJSONWritingOptions(rawValue: 0))
            let jsonString = NSString(data: jsonData, encoding: NSUTF8StringEncoding)! as String
            return jsonString
            
        } catch {
            
            return "{error:could not parse}";
            
        }
    }
    
    
    // Send a Wall Socket to the Server
    func sendWallSocket(latitude: Double, longitude: Double, description: NSString, image: NSString, count: NSString){
        let dict = [
            "endpoint":"plug","action":"add",
            "lat":latitude,
            "lon":longitude,
            "description":description,
            "image":image,
            "slots":count,
        ]
        rawSend(toJSON(dict));
    }
    
    func askForSockets(latitude: Double, longitude: Double, radius:Double){
        let dict = [
            "endpoint":"plug","action":"get",
            "lat":latitude,
            "lon":longitude,
            "radius":radius,
        ]
        rawSend(toJSON(dict as! Dictionary<String, AnyObject>));
    }
    
    func getImage(){
        let dict = [
            "endpoint":"plug",
            "action":"getImage",
            "id":caption,
        ]
        rawSend(toJSON(dict as! Dictionary<String, AnyObject>));
    }
    
    func rawSend(data:String){
        self.socketIO.emit(endpoint,[data]);
        
    }
    
    func popUpSetter(capt:Int){
        caption = capt;
    }
    
    func popUpGetter() -> Int{
        return caption;
    }
    
    func rateUp(){
        let dict = [
            "endpoint":"plug",
            "action":"rateUp",
            "id":caption,
        ]
        rawSend(toJSON(dict as! Dictionary<String, AnyObject>));
    }
    
    func rateDn(){
        let dict = [
            "endpoint":"plug",
            "action":"rateDn",
            "id":caption,
        ]
        rawSend(toJSON(dict as! Dictionary<String, AnyObject>));
    }
    
}
