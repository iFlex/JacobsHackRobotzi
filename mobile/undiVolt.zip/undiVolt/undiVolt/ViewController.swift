//
//  ViewController.swift
//  undiVolt
//
//  Created by Cornel Amariei on 17/10/15.
//  Copyright © 2015 Cornel Amariei. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import QuartzCore

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    // OUTLETS --------------------------------------
    @IBOutlet weak var Map: MKMapView!
    
    // DEFINES --------------------------------------
    
    let locationManager = CLLocationManager();
    
    var globalLongitude = 8.64991512660747;
    var globalLatitude = 53.168131955829;
    
    
    // Things to be sent:
    
    var sendLongitude = 0.0;
    var sendLatitude = 0.0;
    
    // Socket Timer
    var socketTimer = NSTimer();
    var requestSocketsTimer = NSTimer();
    
    var allowGetSockets = true;
    var pinRetention = Dictionary<Int,AnyObject>();
    // CLASS FUNCTIONS ------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Connect to the Server
        comClass.sharedInstance.connect();
        
        
        // Location Services Stuff
        locationManager.delegate = self;
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.requestWhenInUseAuthorization();
        locationManager.startUpdatingLocation();
        
        // APPLE MAPS STUFF
        
        Map.delegate = self
        Map.showsUserLocation = true
        
        let regionRadius: CLLocationDistance = 300
        let initPosition = CLLocation(latitude: globalLatitude, longitude: globalLongitude)
        
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(initPosition.coordinate, regionRadius, regionRadius);
        
        Map.setRegion(coordinateRegion, animated: true);
        
        // START SOCKET TIMER
        
        socketTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("timerTick"), userInfo: nil, repeats: true);
        
    }
    
    override func viewWillAppear(animated: Bool) {
        print("ye");
        allowGetSockets = true;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // DELEGATES FOR LOCATION ---------------------
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last;
        
        globalLatitude = Float64(location!.coordinate.latitude);
        globalLongitude = Float64(location!.coordinate.longitude);
        
        ///locationManager.stopUpdatingLocation();
    }
    
    // TIMER TICK FUNCITON
    
    func timerTick(){
        updateSockets();
    }
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        

    }
    
    func mapView(mapView: MKMapView!, viewForAnnotation annotation:MKAnnotation!)-> MKAnnotationView!{
        // 1
        let identifier = "Capital"
        
        // 2
        //if annotation.isKindOfClass(Capital.self) {
            // 3
            var annotationView = mapView.dequeueReusableAnnotationViewWithIdentifier(identifier)
            
            if annotationView == nil {
                //4
                annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                annotationView!.canShowCallout = true
                
                // 5
                let btn = UIButton(type: .DetailDisclosure)
                annotationView!.rightCalloutAccessoryView = btn
            } else {
                // 6
                annotationView!.annotation = annotation
            }
            
            return annotationView
        //}
        
        // 7
        //return nil
    }
    
    func mapView(mapView: MKMapView!, annotationView view: MKAnnotationView!, calloutAccessoryControlTapped control: UIControl!) {
        let capital = view.annotation
        //String(capital!.title)
        var items = String(capital!.title).componentsSeparatedByString("#")
        //print(String(items[1]));
        var tempItems = String(items[1]);
        var finalString = "";
        var number = "";
        for character in tempItems.characters {
            if character >= "0" && character <= "9" {
                number.append(character);
            } else {
                break;
            }
        }
        
      //  print(finalString);
        
        
        
        //let placeName = items[0]
        let placeInfo = "";
        
        
        comClass.sharedInstance.popUpSetter(Int(number)!);
        
        let popUp = popUpViewController(nibName: "popUpViewController", bundle: nil);
        
        popUp.modalTransitionStyle = UIModalTransitionStyle.CrossDissolve;
        
        self.presentViewController(popUp, animated: true, completion: nil);
        
    }
    
    // FUNCTIONS TO SHOW THE SOCKETS
    func addMapMarker(id:Int,lat:Double,lon:Double,desc:String,slots:Int,rank:Int){
        var location = CLLocationCoordinate2D(
            latitude: lat,
            longitude: lon
        )
        
        var span = MKCoordinateSpanMake(0.5, 0.5)
        var region = MKCoordinateRegion(center: location, span: span)
        
        Map.setRegion(region, animated: true)
        
        var annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = desc+" #"+String(id)
        annotation.subtitle = "No. of sockets "+String(slots)+" Rank:"+String(rank);
        
        Map.addAnnotation(annotation)
    }
    
    func updateMapMarker(id:Int,desc:String,slots:Int,rank:Int){
        /*var annotation = MKPointAnnotation()
        annotation.title = desc+" #"+String(id)
        annotation.subtitle = "No. of sockets "+String(slots)+" Rank:"+String(rank);
        
        Map.addAnnotation(annotation)*/
        //TOOD: modify annotation
    }
    
    func updateSockets(){
        
        if allowGetSockets {
            comClass.sharedInstance.askForSockets(globalLatitude, longitude: globalLongitude, radius: 10)
            
            var sockets = comClass.sharedInstance.getLatestData("plug");
            if sockets != nil {
                if sockets["rows"] != nil {
                    for key in sockets["rows"] as! [AnyObject] {
                        if pinRetention[key["id"] as! Int] == nil{
                            pinRetention[key["id"] as! Int] = key;
                            addMapMarker(key["id"] as! Int,
                                lat: key["lat"] as! Double,
                                lon: key["lon"] as! Double,
                                desc: key["description"] as! String,
                                slots: key["slots"] as! Int,
                                rank:key["rank"] as! Int);
                        } else {
                            pinRetention[key["id"] as! Int] = key;
                            updateMapMarker(key["id"] as! Int,
                                 desc: key["description"] as! String,
                                slots: key["slots"] as! Int,
                                rank:key["rank"] as! Int);
                        }
                }
                
                let regionRadius: CLLocationDistance = 300
                let initPosition = CLLocation(latitude: globalLatitude, longitude: globalLongitude)
                
                let coordinateRegion = MKCoordinateRegionMakeWithDistance(initPosition.coordinate, regionRadius, regionRadius);
                
                Map.setRegion(coordinateRegion, animated: true);
                
                comClass.sharedInstance.clearLastData("plug");
                allowGetSockets = false
            }

        }

        }
        
    }
    

    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError){
        
        NSLog("Errors: " + error.localizedDescription);
        
        
    }


}

