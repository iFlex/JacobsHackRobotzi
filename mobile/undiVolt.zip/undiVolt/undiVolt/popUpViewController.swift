//
//  popUpViewController.swift
//  undiVolt
//
//  Created by Cornel Amariei on 18/10/15.
//  Copyright © 2015 Cornel Amariei. All rights reserved.
//

import UIKit

class popUpViewController: UIViewController {

    @IBOutlet weak var image: UIImageView!
    
    
    @IBOutlet weak var descrp: UITextView!
    
    @IBOutlet weak var noSockets: UILabel!
    
    @IBOutlet weak var rank: UILabel!
    
    @IBOutlet weak var stepper: UIStepper!
    
    
    var socketTimer = NSTimer();
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        stepper.autorepeat = false;
        stepper.maximumValue = 1;
        stepper.minimumValue = -1;
        
        descrp.text = String(comClass.sharedInstance.popUpGetter());
        
        comClass.sharedInstance.getImage();
        
        socketTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("timerTick"), userInfo: nil, repeats: true);
        

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func Base64ToImage (base64String: String){
        
        let decodedData = NSData(base64EncodedString: base64String, options: NSDataBase64DecodingOptions())
        var decodedImage = UIImage(data: decodedData!)
        image.image = decodedImage;
    }
    
    
    func timerTick(){
        
        var sockets = comClass.sharedInstance.getLatestData("plug");
        if sockets != nil {
            if sockets["image"] != nil {
                
                Base64ToImage(sockets["image"] as! String);
                
                var rows = sockets["rows"] as! NSArray;
                var row = rows[0] as! Dictionary<String,AnyObject>;
                descrp.text = row["description"] as! String;
                noSockets.text = "No of sockets " + String(row["slots"] as! Int);
                rank.text = "Rank " + String(row["rank"] as! Int);
                
                socketTimer.invalidate();
            }
        }
    }
    
    @IBAction func ranked(sender: AnyObject) {
        NSLog(String(stepper.value))
        if stepper.value > 0 {
            comClass.sharedInstance.rateUp();
        } else {
            comClass.sharedInstance.rateDn();
        }
        
    }
    
    @IBAction func goHome(sender: AnyObject) {
        
        self.dismissViewControllerAnimated(true, completion: nil);
        socketTimer.invalidate();
        
    }
}
