//
//  SocketSendViewController.swift
//  undiVolt
//
//  Created by Cornel Amariei on 17/10/15.
//  Copyright © 2015 Cornel Amariei. All rights reserved.
//

import UIKit
import CoreLocation



class SocketSendViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CLLocationManagerDelegate{
    
    // OUTLETS --------------------------------------
    @IBOutlet weak var Scroller: UIScrollView!
    
    
    @IBOutlet weak var PictureView: UIImageView!
    
    
    @IBOutlet weak var DescriptionView: UITextView!
    @IBOutlet weak var SocketNo: UITextField!
    
    @IBOutlet weak var SendButton: UIButton!
    
    // DEFINES --------------------------------------
    var baseScrollPosition = CGPointMake(0, 0);
    
    let imagePicker = UIImagePickerController();
    
    let locationManager = CLLocationManager();
    
    var globalLongitude = 0.0;
    var globalLatitude = 0.0;
    
    var smallImageSize = CGSizeMake(150,200);
    
    // Things to be sent:
    
    var sendLongitude = 0.0;
    var sendLatitude = 0.0;
    var sendDescription = "";
    var sendNoSockets = NSString();
    var sendImage = UIImage();
    var sendImageString = NSString();
    
    
    
    
    // CLASS FUNCTIONS ------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //imagePicker.delegate = self
        // Do any additional setup after loading the view.
        
        // Send Button initially dissabled
        SendButton.enabled = false;
        
        // Dealing with the Scroll View
        Scroller.contentInset = UIEdgeInsetsMake(0, 0, 800, 0);
        // Add a content offest point
        Scroller.contentOffset = CGPointMake(0, 0);
        
        // Delegate DescriptionView
        DescriptionView.delegate = self;
        
        // Delegate ImagePicker
        imagePicker.delegate = self;
        
        // Location Services Stuff
        locationManager.delegate = self;
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.requestWhenInUseAuthorization();
        locationManager.startUpdatingLocation();
        
        // Astetics
        PictureView.contentMode = .ScaleAspectFit;
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    // CUSTOM FUNCTIONS ----------------------------
    
    
    
    
    
    // CAMERA ACTIONS -----------------------------
    
    // This starts the Camera to take a photo and it sends it to the UIImageView
    @IBAction func takePhoto(sender: AnyObject) {
        
        if UIImagePickerController.isSourceTypeAvailable(
            UIImagePickerControllerSourceType.Camera) {

                imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
                imagePicker.allowsEditing = false;
                
                self.presentViewController(imagePicker, animated: true, completion: nil);

        }
        
    }
    
    func imagePickerController( imagePicker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        self.dismissViewControllerAnimated(true, completion: nil);
        
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage;
            
        PictureView.image = image

        UIImageWriteToSavedPhotosAlbum(image, self, "image:didFinishSavingWithError:contextInfo:", nil);
        
        // Save Location
        
        sendLatitude = globalLatitude;
        sendLongitude = globalLongitude;
        
        // Resize the image
        sendImage =  RBResizeImage(image, targetSize: smallImageSize);
        
        // Generate the Base64 Image String
        sendImageString = UIImageToBase64(sendImage);
        
        // Update the Can Send Button
        SendButton.enabled = true;
        
        
        
    }
    
    // Image save function
    func image(PictureView: UIImage, didFinishSavingWithError error: NSErrorPointer, contextInfo:UnsafePointer<Void>) {
        
        if error != nil {
            let alert = UIAlertController(title: "Save Failed",
                message: "Failed to save image",
                preferredStyle: UIAlertControllerStyle.Alert)
            
            let cancelAction = UIAlertAction(title: "OK",
                style: .Cancel, handler: nil)
            
            alert.addAction(cancelAction)
            self.presentViewController(alert, animated: true,
                completion: nil)
        }
    }
    
    // Function to resize image
    func RBResizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSizeMake(size.width * heightRatio, size.height * heightRatio)
        } else {
            newSize = CGSizeMake(size.width * widthRatio,  size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRectMake(0, 0, newSize.width, newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.drawInRect(rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage
    }
    
    // Function to transform image into base64 String
    func UIImageToBase64 (image: UIImage) -> NSString{
        
        let imageData = UIImagePNGRepresentation(image);
        
        let base64String = imageData!.base64EncodedStringWithOptions(NSDataBase64EncodingOptions.Encoding64CharacterLineLength);
        
        return base64String;
        
    }
    
    // DELEGATES FOR LOCATION ---------------------
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last;
        
        globalLatitude = Float64(location!.coordinate.latitude);
        globalLongitude = Float64(location!.coordinate.longitude);
        
        ///locationManager.stopUpdatingLocation();
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError){
        
        NSLog("Errors: " + error.localizedDescription);
        
        
    }
    
    // EVENTS FOR DESCRIPTION VIEW -------------------
    
    func textViewDidBeginEditing(DescriptionView: UITextView){
    
        DescriptionView.text = "";
        // Scroll to have the view in focus
        var gotoPosition = CGPointMake(0, 0);
        gotoPosition.y = DescriptionView.frame.minY;
        
        gotoPosition.y -= 100;
        
        Scroller.setContentOffset(gotoPosition, animated: true);
        
    }
    
    func textView(DescriptionView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            DescriptionView.resignFirstResponder()
            return false
        }
        
        return true;
    }
    
    func textViewDidEndEditing(DescriptionView: UITextView){
        
        // Update Send Variable
        sendDescription = DescriptionView.text;
        
        // Scroll back to base position
        Scroller.setContentOffset(baseScrollPosition, animated: true);
        
    }

    // EVENTS FOR NUMBER OF SOCKETS ---------------------
    
    @IBAction func socketNoDidBeginEditing(sender: AnyObject) {
        
        // Scroll to have the view in focus
        var gotoPosition = CGPointMake(0, 0);
        gotoPosition.y = SocketNo.frame.minY;
        
        gotoPosition.y -= 200;
        
        Scroller.setContentOffset(gotoPosition, animated: true);
        
    }
    
    @IBAction func dismissKeyboard(sender: AnyObject) {
        
        
        // Set the sender
        sendNoSockets = self.SocketNo.text!;
        
        // Hide the keyboard
        self.resignFirstResponder();
        
        // Scroll back to base position
        Scroller.setContentOffset(baseScrollPosition, animated: true);
        
    }
    
    
    // NAVIGATION MOVEMENT
    // Goes back to the MapViewController - main view
    @IBAction func goBack(sender: AnyObject) {
        
        comClass.sharedInstance.sendWallSocket(sendLatitude, longitude: sendLongitude, description: sendDescription, image: sendImageString, count: sendNoSockets);
        self.dismissViewControllerAnimated(true, completion: nil);
        
    }
    
    // EVENTS FOR NUMBER OF SOCKETS ---------------------
    @IBAction func sendSocket(sender: AnyObject) {
        
        comClass.sharedInstance.sendWallSocket(sendLatitude, longitude: sendLongitude, description: sendDescription, image: sendImageString, count: sendNoSockets);
        
        self.dismissViewControllerAnimated(true, completion: nil);
        
        
    }
}
